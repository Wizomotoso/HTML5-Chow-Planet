function checkNum() 
{
	if (!form1.number.value.match(/^[0-9]+$/) && form1.number.value !="")
               {
                    form1.number.value="";
                    form1.number.focus(); 
                    alert("Please Enter only numbers");
               }
}

function checkQuantity() 
{
	if (!form1.quantity.value.match(/^[0-9]+$/) && form1.quantity.value !="")
               {
                    form1.quantity.value="";
                    form1.quantity.focus(); 
                    alert("Please Enter only numbers in text");
               }
}

function checkFirstName() 
{
  if (!form1.usrname.value.match(/^[a-zA-Z]+$/) && form1.usrname.value !="")
               {
                    form1.usrname.value="";
                    form1.usrname.focus(); 
                    alert("Please Enter only alphabets in text");
               }	
}

function checkLastName() 
{
	if (!form1.usrname1.value.match(/^[a-zA-Z]+$/) && form1.usrname1.value !="")
               {
                    form1.usrname1.value="";
                    form1.usrname1.focus(); 
                    alert("Please Enter only alphabets in text");
               }
}

function check()
{
if((document.form1.usrname.value!="")&&(document.form1.usrname1.value!="")&&(document.form1.mail.value!="")&&(document.form1.quantity.value!="")&&(document.form1.number.value!="")&&(document.form1.address.value!="")&&(document.form1.sel.value=="bigboy"))
{
alert("Hi. Your Order for the Big Boy Package is being prepared as we speak.Ths Package Consists of One HamBurger, A plate of Rice and Chicken, with a drink. It would be delivered soon. Thanks For patronizing Chow Planet.");
}

else if((document.form1.usrname.value!="")&&(document.form1.usrname1.value!="")&&(document.form1.mail.value!="")&&(document.form1.quantity.value!="")&&(document.form1.number.value!="")&&(document.form1.address.value!="")&&(document.form1.sel.value=="randc"))
{
alert("Hi. Your Order for Rice and Chicken is being prepared as we speak. It would be delivered soon. Thanks For patronizing Chow Planet.");
}

else if((document.form1.usrname.value!="")&&(document.form1.usrname1.value!="")&&(document.form1.mail.value!="")&&(document.form1.quantity.value!="")&&(document.form1.number.value!="")&&(document.form1.address.value!="")&&(document.form1.sel.value=="chickenpie"))
{
alert("Hi. Your Order for Chicken Pie is being prepared as we speak. It would be delivered soon. Thanks For patronizing Chow Planet.");
}

else if((document.form1.usrname.value!="")&&(document.form1.usrname1.value!="")&&(document.form1.mail.value!="")&&(document.form1.quantity.value!="")&&(document.form1.number.value!="")&&(document.form1.address.value!="")&&(document.form1.sel.value=="pizza"))
{
alert("Hi. Your Order for Pizza is being prepared as we speak. It would be delivered soon. Thanks For patronizing Chow Planet.");
}

else if((document.form1.usrname.value!="")&&(document.form1.usrname1.value!="")&&(document.form1.mail.value!="")&&(document.form1.quantity.value!="")&&(document.form1.number.value!="")&&(document.form1.address.value!="")&&(document.form1.sel.value=="scotch"))
{
alert("Hi. Your Order for Scotch Egg(s) is being prepared as we speak. It would be delivered soon. Thanks For patronizing Chow Planet.");
}

else if((document.form1.usrname.value!="")&&(document.form1.usrname1.value!="")&&(document.form1.mail.value!="")&&(document.form1.quantity.value!="")&&(document.form1.number.value!="")&&(document.form1.address.value!="")&&(document.form1.sel.value=="swallow1"))
{
alert("Hi. Your Order for Amala & Ewedu is being prepared as we speak. It would be delivered soon. Thanks For patronizing Chow Planet.");
}

else{
     alert("Error. Please make sure you have all forms filled.");
}
}